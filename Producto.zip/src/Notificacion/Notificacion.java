package Notificacion;

public interface Notificacion{
        void enviar(String mensaje);
    }
