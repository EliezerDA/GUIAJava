public class CalculoImpuestos {
    Double impuesto = 0.13;

    public Double calcularimpuesto(Double precio){
        return precio + (precio * impuesto);
    }
}
